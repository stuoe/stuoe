from setuptools import setup

setup(
    name='stuoe-project',
    version='0.0.1',
    author='stuoe',
    author_email='snbckcode@gmail.com',
    url='https://github.com/stuoe/stuoe',
    description=u'吃枣药丸',
    packages=['stuoe'],
    install_requires=[]
    
)